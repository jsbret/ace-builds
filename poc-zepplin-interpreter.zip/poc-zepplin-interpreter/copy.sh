#!/usr/bin/env bash
cp ./target/poc-*.jar /Users/jsbret/Documents/devel/programs/zeppelin-0.7.3-bin-all/interpreter/tql/tql-interpreter.jar