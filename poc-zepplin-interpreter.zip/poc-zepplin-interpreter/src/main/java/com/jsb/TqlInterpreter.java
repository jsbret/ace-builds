package com.jsb;

import org.apache.zeppelin.interpreter.Interpreter;
import org.apache.zeppelin.interpreter.InterpreterContext;
import org.apache.zeppelin.interpreter.InterpreterResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Properties;

public class TqlInterpreter extends Interpreter {


    public static final String TQL_SERVICE_URL = "tql.service.url";
    public static final String TQL_SERVICE_REQUEST_METHOD = "tql.service.request.method";
    public static final String TQL_SERVICE_ACCEPT_HEADER = "tql.service.accept.header";

    private Logger logger = LoggerFactory.getLogger(TqlInterpreter.class);
    private HttpURLConnection conn;


    public TqlInterpreter(Properties property) {
        super(property);
    }

    @Override
    public void open() {

    }

    @Override
    public void close() {
        conn.disconnect();
    }

    @Override
    public InterpreterResult interpret(String tql, InterpreterContext interpreterContext) {

        StringBuilder result;

        try {
            String urlAsString = getProperty(TQL_SERVICE_URL);
            URL url = new URL(urlAsString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod(getProperty(TQL_SERVICE_REQUEST_METHOD));
            conn.setRequestProperty("Accept", getProperty(TQL_SERVICE_ACCEPT_HEADER));

            OutputStream os = conn.getOutputStream();
            os.write(tql.getBytes());
            os.flush();

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                return new InterpreterResult(InterpreterResult.Code.ERROR, "Failed : HTTP error code : " + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            logger.info("Handle result from Server");
            result = new StringBuilder();
            String output;
            while ((output = br.readLine()) != null) {
                logger.info(output);
                result.append(output).append("\n");
            }

            if (result.length() == 0) {
                new InterpreterResult(InterpreterResult.Code.SUCCESS, InterpreterResult.Type.TEXT, "Empty Result");
            }

            return new InterpreterResult(InterpreterResult.Code.SUCCESS, InterpreterResult.Type.TABLE, result.toString());
        } catch (IOException e) {
            logger.error("Failed to send the request {}", tql, e);
            return new InterpreterResult(InterpreterResult.Code.ERROR, e.getMessage());
        }finally {
            conn.disconnect();
        }

    }

    @Override
    public void cancel(InterpreterContext interpreterContext) {

    }

    @Override
    public FormType getFormType() {
        return FormType.NONE;
    }

    @Override
    public int getProgress(InterpreterContext interpreterContext) {
        return 0;
    }
}
